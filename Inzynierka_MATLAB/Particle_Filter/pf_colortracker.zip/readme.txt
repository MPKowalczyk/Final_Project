Video tracking demo by particle Filter 


Please run "mexme_pf_color_tracker.m" to compile all mex-files.

ATTENTION, be sure to setup your matlab system by typing at least one "mex -setup".
Please prefer C compiler such MSCV/Intel CPP/GCC. A free version of MSVC express can be downloaded 
for windows systems.

Run the two demo test_pf_colortracker.m and test_pf_colortracker2.m